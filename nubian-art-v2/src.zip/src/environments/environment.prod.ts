export const environment = {
  firebase: {
    projectId: 'nubian-art-agancy',
    appId: '1:60364774046:web:f701a8841011873618f98f',
    storageBucket: 'nubian-art-agancy.appspot.com',
    locationId: 'us-central',
    apiKey: 'AIzaSyADb7yMQ7pUjx9-4RZDvqaDn0e9RyWE3LA',
    authDomain: 'nubian-art-agancy.firebaseapp.com',
    messagingSenderId: '60364774046',
    measurementId: 'G-QFQVFTV36W',
  },
  production: true
};
