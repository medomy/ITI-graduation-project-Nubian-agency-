export interface IProduct {
  id?: string;
  title: string;
  description: string;
  size: string;
  price: number;
  images: {
    mainImage: string;
    subImages: Array<string>;
  };
  // special?: {
  //   frameColor?: Array<string>;
  //   message?: string;
  //   image?: string;
  // };
  artistID: string;
  categoryID: string;
  TimeStamp: {
    createdAt: Date;
    updatedAt?: Date;
    removedAt?: Date;
  };
}
