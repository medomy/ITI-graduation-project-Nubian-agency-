export interface Iwishlist {
    //id : string,
    productsIds: Array<string>,
    userUid: string,
    timestamp: {
        createdAt: Date,
        removedAt?: Date,
        updatedAt?: Date,
    }
}
