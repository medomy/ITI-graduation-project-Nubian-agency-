export interface Iartist {
  id: string,
  country: string,
  created_at: Date,
  dateOfBirth: Date,
  email: string,
  gender: string,
  name: string,
  recruit_time: Date,
  updated_at: Date
}
