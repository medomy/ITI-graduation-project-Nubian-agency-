export interface Category {
  //id : string,
  created_at: string;
  image: string;
  name: string;
  removed_at: Date;
  updated_at: string;
}
