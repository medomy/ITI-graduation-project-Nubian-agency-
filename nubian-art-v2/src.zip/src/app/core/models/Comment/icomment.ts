export interface Icomment {
    id: string,
    body: string,
    createdAt: Date,
    rate: number,
    removedAt: Date,
    productId: string,
    title: string,
    updatedAt: Date,
    userId: string
}
