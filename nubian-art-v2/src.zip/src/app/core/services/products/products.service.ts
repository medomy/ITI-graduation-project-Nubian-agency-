import { Injectable } from '@angular/core';
import {
  Firestore,
  collection,
  collectionData,
  onSnapshot,
  getDocs,
  getDoc,
} from '@angular/fire/firestore';
import {
  CollectionReference,
  deleteDoc,
  doc,
  Query,
  setDoc,
} from '@firebase/firestore';
import { docData } from 'rxfire/firestore';
import { IProduct } from '../../models/products/i-product';

@Injectable({
  providedIn: 'root',
})
export class ProductsService {
  constructor(private firestore: Firestore) {}

  //getAll
  getProducts() {
    // let data = collection(this.firestore, 'services');

    // to get them with id and make the reusable
    // let products = [];
    // const querySnapshot = await getDocs(collection(this.firestore, 'services'));

    // querySnapshot.forEach((docu) => {
    //   products.push(docu.data());
    // });
    // //return collectionData(data);
    // console.log(products);
    // return products;
    const dataCollection = collection(this.firestore, 'services');
    return collectionData(dataCollection);
  }

  /**
   * not need this funcation beacuse id add auto with new product
   */

  // getProductsWithID() {
  //   let data = collection(this.firestore, 'services');
  //   const _products = [];
  //   onSnapshot(data, async (querySnapshot) => {
  //     await querySnapshot.forEach((doc) => {
  //       _products.push(doc.data());
  //     });
  //   });
  //   console.log(_products);
  //   return _products;
  // }
  //get by id
  getOneProduct(id) {
    let oneProduct = doc(this.firestore, `services`, id);
    return docData(oneProduct);
  }

  //add

  async addProduct(product: IProduct) {
    const newProduct = await doc(collection(this.firestore, 'services'));
    setDoc(newProduct, { ...product, id: newProduct.id });
    // await setDoc(newProduct,{product});
    console.log('prodcut add successfully...');
  }

  //update
  async updateProduct(id, newprop) {
    await setDoc(
      doc(this.firestore, 'services', id),
      newprop,
      { merge: true }
    );
  }

  //remove

  removeProduct(id) {
    deleteDoc(doc(this.firestore, 'services', id));
  }
}
