import { Injectable } from '@angular/core';
import {
  Firestore,
  collection,
  collectionData,
  onSnapshot,
  getDocs,
} from '@angular/fire/firestore';
import { deleteDoc, doc, setDoc } from '@firebase/firestore';
import { docData } from 'rxfire/firestore';
import { Iorder } from '../../models/Order/iorder';

@Injectable({
  providedIn: 'root',
})
export class OrderService {
  constructor(private firestore: Firestore) {}

  //getAll
  async getOrders() {
    //let data = collection(this.firestore, "order");
    let Orders = [];
    const querySnapshot = await getDocs(collection(this.firestore, 'order'));
    querySnapshot.forEach((docu) => {
      Orders.push({ ...docu.data(), id: docu.id });
    });
    return Orders;
    //return collectionData(data);
  }
  /*getOrders() {
  let data = collection(this.firestore, "order");
  const Orders = [];
  onSnapshot(data, (querySnapshot) => {

    querySnapshot.forEach((doc) => {
      Orders.push({ ...doc.data(), id: doc.id })
    });

  });
  return Orders

}*/

  //get by id
  getOneOrder(id) {
    let oneOrder = doc(this.firestore, 'order', id);
    return docData(oneOrder);
  }

  //add

  async addOrder(order: Iorder) {
    await setDoc(doc(collection(this.firestore, 'order')), order);
  }
  //update
  async updateOrder(Id, newProp) {
    await setDoc(doc(collection(this.firestore, 'order', Id)), newProp, {
      merge: true,
    });
  }
  //remove

  removeOrder(Id) {
    deleteDoc(doc(this.firestore, 'order', Id));
  }
}
