import { Injectable } from '@angular/core';
import {
  Firestore,
  collection,
  collectionData,
  onSnapshot,
} from '@angular/fire/firestore';
import { deleteDoc, doc, setDoc } from '@firebase/firestore';
import { docData } from 'rxfire/firestore';
import { Category } from '../../models/category/category';
@Injectable({
  providedIn: 'root',
})
export class CategoriesService {
  constructor(private firestore: Firestore) {
    this.getcategoriess();
  }

  //getAll
  /*getcategories() {
    let data = collection(this.firestore, "category");
    return collectionData(data);
  }*/

  getcategoriess() {
    // let data = collection(this.firestore, 'category');
    // const categories = [];
    // onSnapshot(data, (querySnapshot) => {
    //   querySnapshot.forEach((doc) => {
    //     categories.push({ ...doc.data(), id: doc.id, isUpdate: false });
    //   });
    // });
    // return categories;

    const dataCollection = collection(this.firestore, 'category');
    return collectionData(dataCollection);
  }

  //get by id

  // returns an observable (must subscribe after)
  getOneCategory(id) {
    let oneCategory = doc(this.firestore, `category`, id);
    return docData(oneCategory);
  }

  //add

  async addCategory(category: Category) {
    // await setDoc(doc(collection(this.firestore, 'category')), category);

    const newCat = await doc(collection(this.firestore, 'category'));
    setDoc(newCat, { ...category, id: newCat.id });
  }

  //update (newcat is the added property in an object)
  async updateCategory(id: string, newcat) {
    await setDoc(doc(this.firestore, 'category', id), newcat, { merge: true });
  }
  //remove

  removeCategory(id) {
    deleteDoc(doc(this.firestore, 'category', id));
  }
}
