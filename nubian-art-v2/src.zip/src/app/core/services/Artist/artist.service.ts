import { Injectable } from '@angular/core';
import { Firestore, collection, collectionData, onSnapshot, getDocs } from '@angular/fire/firestore';
import { deleteDoc, doc, setDoc } from '@firebase/firestore';
import { docData } from 'rxfire/firestore';
import { Iartist } from '../../models/Artist/iartist';

@Injectable({
  providedIn: 'root'
})
export class ArtistService {

  constructor(private firestore: Firestore) { }

  //getAll
  async getArtists() {
    //let data = collection(this.firestore, "artist");
    // to get them with id and make the reusable
    let Artists = [];
    const querySnapshot = await getDocs(collection(this.firestore, "artist"));
    querySnapshot.forEach((docu)=>{
      Artists.push({...docu.data() , id : docu.id});
    })
    return Artists;
    //return collectionData(data);
  }
  /*getArtists() {
    let data = collection(this.firestore, "artist");
    const Artists = [];
    onSnapshot(data, (querySnapshot) => {

      querySnapshot.forEach((doc) => {
        Artists.push({ ...doc.data(), id: doc.id })
      });

    });
    return Artists

  }*/

  //get by id
  getOneArtist(id){
    let oneArtist = doc(this.firestore,`artist`,id);
    return docData(oneArtist);
  }

  //add

  async addArtist(Artist : Iartist){
    await setDoc(doc(collection(this.firestore,"artist")),Artist)
  }

  //update
  async updateArtist(Artist : Iartist, newProp){
    await setDoc(doc(this.firestore,"artist" , Artist.id),newProp,{merge:true})
  }

  //remove

  removeArtist(Artist : Iartist){
    deleteDoc(doc(this.firestore,"artist",Artist.id));
  }

}
