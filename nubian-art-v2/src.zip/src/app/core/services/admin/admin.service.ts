import { Injectable } from '@angular/core';
import {
  Firestore,
  collection,
  collectionData,
  doc,
  docData,
  setDoc,
  deleteDoc,
  getDocs,
  query,
  where,
} from '@angular/fire/firestore';
@Injectable({
  providedIn: 'root',
})
export class AdminService {
  constructor(private db: Firestore) {}

  getAdmin(id) {
    const data = query(
      collection(this.db, 'users'),
      where('isAdmin', '==', true),
      where('uid', '==', id)
    );
    return collectionData(data);
  }
}
