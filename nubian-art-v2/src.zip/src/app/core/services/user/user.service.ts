import { Iuser } from './../../models/user/iuser';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import {
  Firestore,
  collection,
  collectionData,
  doc,
  docData,
  setDoc,
  deleteDoc,
  getDocs,
  query,
  where,
} from '@angular/fire/firestore';
@Injectable({
  providedIn: 'root',
})
export class UserService {
  userData: Iuser;

  constructor(
    private router: Router,
    private http: HttpClient,
    private db: Firestore
  ) {}

  //create user
  createUser = async ({ data }) => {
    this.userData = {
      uid: data.uid,
      email: data.email,
      displayName: data.displayName,
      phoneNumber: data.phoneNumber,
      emailVerified: data.emailVerified,
      avatar: data.photoURL,
      birthDate: '',
      gender: '',
      isAdmin: false,
      TimeStamp: {
        createdAt: data.metadata.creationTime,
        lastSignInTime: data.metadata.lastSignInTime,
        updatedAt: '',
        removedAt: '',
      },
    };
    await setDoc(doc(collection(this.db, 'users')), this.userData);
  };

  //update profile

  //update product
  // updatedata.User(id: any, data: {}) {
  //   setDoc(doc(this.db, 'data.user', `${id}`), data, { merge: true });
  // }

  //get one user
  //get by id
  getOneUser(id) {
    const data = query(collection(this.db, 'users'), where('uid', '==', id));
    return collectionData(data);
  }

  // getting all users
  async getUsers() {
    let users = [];
    const querySnapshot = await getDocs(collection(this.db, 'users'));
    querySnapshot.forEach((docu) => {
      users.push({ ...docu.data(), id: docu.id });
    });
    return users;
  }
  async getUsersByuid(uid) {
    let _users = [];
    this.getUsers().then((users) => {
      users.forEach((user) => {
        if ((user.uid = uid)) {
          _users.push(user);
        }
      });
    });
    return _users;
  }
  removeuser(id) {
    deleteDoc(doc(this.db, 'users', id));
  }
}
