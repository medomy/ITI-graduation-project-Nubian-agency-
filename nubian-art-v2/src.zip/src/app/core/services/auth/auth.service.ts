import { AddressService } from './../address/address.service';
import { Iuser } from './../../models/user/iuser';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { take } from 'rxjs/operators';
import {
  Auth,
  signOut,
  signInWithPopup,
  user,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  sendEmailVerification,
  sendPasswordResetEmail,
  getAdditionalUserInfo,
  OAuthProvider,
  linkWithPopup,
  unlink,
  updateEmail,
  updatePassword,
  User,
  reauthenticateWithPopup,
  authState,
  onAuthStateChanged,
  GoogleAuthProvider,
  FacebookAuthProvider,
} from '@angular/fire/auth';

import { UserService } from './../user/user.service';
import { Router } from '@angular/router';
import { IAddress } from '../../models/address/iAddress';
import { WishlistService } from '../Wishlist/wishlist.service';
import { async } from '@firebase/util';
@Injectable({
  providedIn: 'root',
})
export class AuthService {
  userState: any;
  user$: Observable<User | null>;
  loginStatus: boolean = false;
  userExists: boolean = false;
  isAdminStatus: boolean = false;
  constructor(
    private auth: Auth,
    private userService: UserService,
    private addressService: AddressService,
    private router: Router,
    private wishlistservice: WishlistService
  ) {
    this.auth.onAuthStateChanged((user) => {
      if (user) {
        this.loginStatus = true;
        this.userState = user;
        localStorage.setItem('user', JSON.stringify(user));

        // this.userService.getOneUser(user.uid).subscribe((data) => {
        //   localStorage.setItem(
        //     'user',
        //     JSON.stringify({
        //       uid: user.uid,
        //       displayName: user.displayName,
        //       email: user.email,
        //       lastLoginAt: user.metadata.lastSignInTime,
        //       photoURL: user.photoURL,
        //       phoneNumber: data[0].phoneNumber,
        //     })
        //   );
        // });
      } else {
        localStorage.removeItem('user');
      }
    });
  }

  /* Login */
  async Login(data) {
    const credential = await signInWithEmailAndPassword(
      this.auth,
      data.email,
      data.password
    );

    await this.router.navigate(['/home']);
  }

  /* Register */
  async Register(data) {
    const credential = await createUserWithEmailAndPassword(
      this.auth,
      data.email,
      data.password
    );
    await updateProfile(credential.user, {
      displayName: data.name,
      photoURL:
        'https://www.pngitem.com/pimgs/m/522-5220445_anonymous-profile-grey-person-sticker-glitch-empty-profile.png',
    });

    // create address in db
    await this.addressService.createAddress({ data: { ...credential.user } });

    // create user in db
    await this.userService.createUser({
      data: { ...credential.user, phoneNumber: data.phone },
    });
    // create wishlist in db

    await this.router.navigate(['/home']);
  }

  /*login  with google */
  async loginGoogle() {
    try {
      const credential = await signInWithPopup(
        this.auth,
        new GoogleAuthProvider()
      );
      await this.userService.getUsers().then((users) => {
        users.forEach((user) => {
          if (user.uid == credential.user.uid) {
            this.userExists = true;
          }
        });
      });
      if (this.userExists == false) {
        // create address in db
        await this.addressService.createAddress({
          data: { ...credential.user },
        });
        // create user in db
        await this.userService.createUser({
          data: { ...credential.user, phoneNumber: ' ' },
        });
        // create wishlist in db
        await this.wishlistservice.createWishlist({
          data: { ...credential.user },
        });
      }
      await this.router.navigate(['/home']);
    } catch (error) {
      // Handle Errors here.
      const errorCode = error.code;
      const errorMessage = error.message;
      // The email of the user's account used.
      const email = error.email;
      // The AuthCredential type that was used.
      const credential = GoogleAuthProvider.credentialFromError(error);
    }
  }
  /*login  with facebook */
  async loginFacebook() {
    try {
      const credential = await signInWithPopup(
        this.auth,
        new FacebookAuthProvider()
      );
      // create address in db
      await this.addressService.createAddress({ data: { ...credential.user } });
      // create user in db
      await this.userService.createUser({
        data: { ...credential.user, phoneNumber: '' },
      });
      // create wishlist in db
      await this.wishlistservice.createWishlist({
        data: { ...credential.user },
      });
      await this.router.navigate(['/home']);
      console.log(user);
    } catch (error) {
      // Handle Errors here.
      const errorCode = error.code;
      const errorMessage = error.message;
      // The email of the user's account used.
      const email = error.email;
      // The AuthCredential type that was used.
      const credential = GoogleAuthProvider.credentialFromError(error);
    }
  }
  async resetPassword(email: string): Promise<any> {
    // sends reset password email
    await sendPasswordResetEmail(this.auth, email);
  }

  /* Logout */
  async Logout() {
    signOut(this.auth)
      .then(() => {
        this.loginStatus = false;
        window.localStorage.removeItem('user');
        window.localStorage.removeItem('admin');
        this.router.navigate(['auth/login']);
      })
      .catch((error) => {
        console.log(error);
      });
  }
  //adminLogout
  async LogoutAdmin() {
    signOut(this.auth)
      .then(() => {
        this.loginStatus = false;
        window.localStorage.removeItem('user');
        window.localStorage.removeItem('admin');
        this.router.navigate(['/admin/admin-auth/login']);
      })
      .catch((error) => {
        console.log(error);
      });
  }
  //get user
  get getUser() {
    return this.userState;
  }
  get getuserLocal() {
    return JSON.parse(window.localStorage.getItem('user'));
  }

  /*isLogin*/
  // get isLoggedIn(): boolean {
  //   return this.loginStatus;
  // }

  get isLoggedIn(): boolean {
    return !!this.getuserLocal;
  }
}
