import { Injectable } from '@angular/core';
import { Auth, user, User, authState, signOut } from '@angular/fire/auth';
import { AdminService } from '../../admin/admin.service';
import { AuthService } from '../auth.service';
import { Observable } from 'rxjs/Observable';
import { switchMap } from 'rxjs/internal/operators/switchMap';
@Injectable({
  providedIn: 'root',
})
export class AutAdminService {
  isAdminStatus: boolean = false;
  user$: Observable<User | null>;

  constructor(
    private auth: Auth,
    private authService: AuthService,
    private adminService: AdminService
  ) {
    this.auth.onAuthStateChanged((user) => {
      if (user) {
        localStorage.setItem('admin', JSON.stringify({ isAdmin: true }));
      } else {
        localStorage.removeItem('admin');
      }
    });
  }

  get user(): any {
    return this.authService.getuserLocal;
  }

  get getIsAdminLocal(): any {
    return JSON.parse(window.localStorage.getItem('admin'));
  }
  /*isLogin*/
  get isLoggedInAdmin(): boolean {
    return !!this.getIsAdminLocal;
  }
}
