import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css'],
})
export class AdminLoginComponent implements OnInit {
  user = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', [
      Validators.minLength(8),
      Validators.required,
    ]),
  });
  errors: string[] = [];
  constructor(private router: Router) {}

  ngOnInit(): void {}

  get email() {
    return this.user.get('email');
  }

  get password() {
    return this.user.get('password');
  }

  login() {
    if (this.user.invalid) {
      if (this.email?.invalid) this.errors.push('Email Is Invalid');
      if (this.password?.invalid) this.errors.push('Password Is Invalid');
      return;
    }
    console.log(this.user.value);
    this.router.navigate(['/shop']);
  }
}
