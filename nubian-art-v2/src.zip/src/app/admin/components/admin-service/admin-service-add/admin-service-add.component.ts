import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-service-add',
  templateUrl: './admin-service-add.component.html',
  styleUrls: ['./admin-service-add.component.css']
})
export class AdminServiceAddComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
