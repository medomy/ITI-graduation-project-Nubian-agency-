import { Component, OnInit } from '@angular/core';
import { CategoriesService } from 'src/app/core/services/categories/categories.service';
import { ProductsService } from 'src/app/core/services/products/products.service';

@Component({
  selector: 'app-admin-service-all',
  templateUrl: './admin-service-all.component.html',
  styleUrls: ['./admin-service-all.component.css'],
})
export class AdminServiceAllComponent implements OnInit {
  products = [];
  categeory;
  loader: boolean = false;
  constructor(
    private prdService: ProductsService,
    private categoryservice: CategoriesService
  ) {
    this.prdService.getProducts().subscribe((data) => {
      // let categeory= this.categoryservice.getOneCategory(data.categoryID)
      data.map((item) => {
        this.categeory = this.categoryservice
          .getOneCategory(item.categoryID)
          .subscribe((data2) => {
            console.log(item.categoryID);
            let mapITem = { ...item, category: data2 };
            this.products.push(mapITem);
            this.loader = true;
          });
      });
      console.log(this.products);
    });
  }

  ngOnInit(): void {}
}
