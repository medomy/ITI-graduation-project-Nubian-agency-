import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-service-update',
  templateUrl: './admin-service-update.component.html',
  styleUrls: ['./admin-service-update.component.css']
})
export class AdminServiceUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
