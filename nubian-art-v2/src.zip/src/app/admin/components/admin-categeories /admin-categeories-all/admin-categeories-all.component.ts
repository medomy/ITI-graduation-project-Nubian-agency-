import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs-compat/Observable';
import { CategoriesService } from 'src/app/core/services/categories/categories.service';
import { NgbPaginationConfig } from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-admin-categeories-all',
  templateUrl: './admin-categeories-all.component.html',
  styleUrls: ['./admin-categeories-all.component.css'],
})
export class AdminCategeoriesAllComponent implements OnInit {
  page = 4;

  pageSize = 4;
  // collectionSize: Observable<any>;

  categories;
  isUpdate: boolean = false;

  constructor(
    private categoryservice: CategoriesService,
    config: NgbPaginationConfig
  ) {
    this.categories = this.categoryservice
      .getcategoriess()
      .subscribe((data) => {
        this.categories = data;
        this.refreshCountries();
        // this.collectionSize = this.categories;
      });

    config.size = 'sm';
    config.boundaryLinks = true;
  }
  ngOnInit(): void {}

  refreshCountries() {
    this.categories.slice(
      (this.page - 1) * this.pageSize,
      (this.page - 1) * this.pageSize + this.pageSize
    );
  }

  update(category) {
    this.isUpdate = true;
  }
  remove(id) {
    console.log(id);
    this.categoryservice.removeCategory(id);
  }
}
