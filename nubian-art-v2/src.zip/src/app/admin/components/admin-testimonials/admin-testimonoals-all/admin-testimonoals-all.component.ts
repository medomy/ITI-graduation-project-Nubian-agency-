import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-testimonoals-all',
  templateUrl: './admin-testimonoals-all.component.html',
  styleUrls: ['./admin-testimonoals-all.component.css']
})
export class AdminTestimonoalsAllComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
