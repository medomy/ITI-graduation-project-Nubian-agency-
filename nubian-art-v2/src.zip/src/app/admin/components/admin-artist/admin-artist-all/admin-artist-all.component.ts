import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-artist-all',
  templateUrl: './admin-artist-all.component.html',
  styleUrls: ['./admin-artist-all.component.css']
})
export class AdminArtistAllComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
