import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminAuthGuard } from '../core/gurds/admin/admin-auth.guard';
import { AdminCategeoriesAddComponent } from './components/admin-categeories /admin-categeories-add/admin-categeories-add.component';
import { AdminCategeoriesAllComponent } from './components/admin-categeories /admin-categeories-all/admin-categeories-all.component';
import { AdminCategeoriesUpdateComponent } from './components/admin-categeories /admin-categeories-update/admin-categeories-update.component';
import { AdminServiceAllComponent } from './components/admin-service/admin-service-all/admin-service-all.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';

const routes: Routes = [
  {
    path: 'admin-auth',
    loadChildren: () =>
      import('./modules/admin-auth/admin-auth.module').then(
        (m) => m.AdminAuthModule
      ),
  },

  {
    path: '',
    component: DashboardComponent,
    canActivate: [AdminAuthGuard],
  },

  {
    path: 'categeories',
    component: AdminCategeoriesAllComponent,
    canActivate: [AdminAuthGuard],
  },
  {
    path: 'categeories/add',
    component: AdminCategeoriesAddComponent,
    canActivate: [AdminAuthGuard],
  },
  {
    path: 'categeories/update/:id',
    component: AdminCategeoriesUpdateComponent,
    canActivate: [AdminAuthGuard],
  },
  {
    path: 'services',
    component: AdminServiceAllComponent,
    canActivate: [AdminAuthGuard],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdminRoutingModule {}
