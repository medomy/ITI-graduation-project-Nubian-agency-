import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminComponent } from './admin.component';
import { SharedModule } from '../client/shared/shared.module';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AdminAboutComponent } from './components/admin-about/admin-about.component';
import { AdminServiceAddComponent } from './components/admin-service/admin-service-add/admin-service-add.component';
import { AdminServiceAllComponent } from './components/admin-service/admin-service-all/admin-service-all.component';
import { AdminServiceUpdateComponent } from './components/admin-service/admin-service-update/admin-service-update.component';
import { AdminArtistAllComponent } from './components/admin-artist/admin-artist-all/admin-artist-all.component';
import { AdminTestimonoalsAllComponent } from './components/admin-testimonials/admin-testimonoals-all/admin-testimonoals-all.component';
import { AdminCategeoriesAllComponent } from './components/admin-categeories /admin-categeories-all/admin-categeories-all.component';
import { AdminCategeoriesAddComponent } from './components/admin-categeories /admin-categeories-add/admin-categeories-add.component';
import { AdminCategeoriesUpdateComponent } from './components/admin-categeories /admin-categeories-update/admin-categeories-update.component';

@NgModule({
  declarations: [
    AdminComponent,
    DashboardComponent,
    AdminAboutComponent,
    AdminServiceAddComponent,
    AdminServiceAllComponent,
    AdminServiceUpdateComponent,
    AdminArtistAllComponent,
    AdminTestimonoalsAllComponent,
    AdminCategeoriesAllComponent,
    AdminCategeoriesAddComponent,
    AdminCategeoriesUpdateComponent,
  ],

  imports: [CommonModule, AdminRoutingModule, SharedModule],
})
export class AdminModule {}
