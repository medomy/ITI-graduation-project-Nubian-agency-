import { Component, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import {
  ActivatedRoute,
  NavigationStart,
  RouteConfigLoadStart,
  Router,
} from '@angular/router';
import { AutAdminService } from './core/services/auth/admin/aut-admin.service';
import 'rxjs/add/operator/filter';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit, OnChanges {
  title = 'nubian-art';
  isRouteAdmin: boolean = false;
  isAdminLogin: boolean = false;
  constructor(
    private authAdminService: AutAdminService,
    private router: Router
  ) {
    router.events.subscribe((event) => {
      if (event instanceof RouteConfigLoadStart) {
        if (event.route.path === 'admin') {
          this.isRouteAdmin = true;
        }

        if (event.route.path === 'admin/admin-auth/login') {
          this.isAdminLogin = true;
        }
      }
    });
  }

  ngOnInit() {}
  ngOnChanges(): void {}

  get loggedInAdmin(): boolean {
    return this.authAdminService.isLoggedInAdmin;
  }
}
