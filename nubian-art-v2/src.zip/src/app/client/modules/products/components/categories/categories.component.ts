import { Component, OnInit } from '@angular/core';
import { CategoriesService } from 'src/app/core/services/categories/categories.service';

@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.css'],
})
export class CategoriesComponent implements OnInit {
  categories;
  constructor(private categoryservice: CategoriesService) {
    this.categoryservice.getcategoriess().subscribe((data) => {
      this.categories = data;
      console.log('cat', data);
    });
  }

  ngOnInit(): void {}
}
