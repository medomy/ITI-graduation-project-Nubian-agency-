import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { NgbRatingConfig } from '@ng-bootstrap/ng-bootstrap';
import { AddtowishlistService } from 'src/app/core/services/addtowishlist/addtowishlist.service';
import { AuthService } from 'src/app/core/services/auth/auth.service';
import { WishlistService } from 'src/app/core/services/Wishlist/wishlist.service';

@Component({
  selector: 'app-product-item',
  templateUrl: './product-item.component.html',
  styleUrls: ['./product-item.component.css']
})
export class ProductItemComponent implements OnInit {
  @Input() product;
  @Output() sendProduct = new EventEmitter();

  addedProductsId = [];

  constructor(
    config: NgbRatingConfig,
    private auth: AuthService,
    private wishListservice: WishlistService,
    private addtowishlist: AddtowishlistService
  ) {
    config.max = 5;
    console.log(this.product);

    this.addtowishlist
      .getWishList()
      .subscribe(
        (wishlistProducts) => (this.addedProductsId = wishlistProducts)
      );
  }

  ngOnInit(): void {
    console.log(this.product);
  }
  takeProduct() {
    this.sendProduct.emit(this.product);
  }

  _AddToWishList(product) {
    if (this.auth.isLoggedIn) {
      this.addtowishlist.addToWishList(product.id);
      this.wishListservice
        .getWishListByUid(this.auth.getUser.uid)
        .then((wishList) =>
          this.wishListservice.updateWishlist(wishList.id, {
            productsIds: this.addedProductsId,
          })
        );
    } else {
      alert('Only members allowed to add to their wishlists');
    }
  }
}
