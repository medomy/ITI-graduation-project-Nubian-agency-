import { Component, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { CartService } from 'src/app/core/services/cart/cart.service';
import { ProductsService } from 'src/app/core/services/products/products.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
})
export class CartComponent implements OnInit {
  page = 1;
  pageSize = 4;

  //----------------------------------------------
  products: any = [];
  grandTotalPrice: number = 0;
  isLoding: boolean = true;

  constructor(
    private cartService: CartService,
    private productService: ProductsService
  ) {
    // this.refreshCountries();

    this.cartService.getCartItems().subscribe((data) => {
      let total = 0;
      let arr = [];
      data.forEach((element) => {
        this.productService
          .getOneProduct(element.productId)
          .subscribe((data) => {
            arr.push({
              data,
              qtn: element.quantity,
              subTotal: element.quantity * data.price,
            });

            total += element.quantity * data.price;
            if (total) {
              this.grandTotalPrice = total;
            } else {
              this.grandTotalPrice = 0;
            }
          });
      });

      this.products = arr;
      this.isLoding = false;
    });
  }

  ngOnInit(): void {}
  ngOnChanges(): void {}

  // refreshCountries() {
  //   this.countries = COUNTRIES.map((country, i) => ({
  //     id: i + 1,
  //     ...country,
  //   })).slice(
  //     (this.page - 1) * this.pageSize,
  //     (this.page - 1) * this.pageSize + this.pageSize
  //   );

  // }

  decreaseItem(productId: any) {
    this.cartService.decreaseItem(productId);
  }
  // emptycart() {
  //   this.cartService.emptyCart();
  // }

  addtocart(productId: any) {
    this.cartService.addToCart(productId);
    // this.products = []
  }

  removeFromCart(productId: any) {
    this.cartService.removeCartItem(productId);
  }
}
