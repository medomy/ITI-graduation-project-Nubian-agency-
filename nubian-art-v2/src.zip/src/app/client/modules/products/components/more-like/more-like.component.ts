import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-more-like',
  templateUrl: './more-like.component.html',
  styleUrls: ['./more-like.component.css']
})
export class MoreLikeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
