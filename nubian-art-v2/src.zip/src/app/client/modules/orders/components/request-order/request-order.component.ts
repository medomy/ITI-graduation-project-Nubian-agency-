import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-request-order',
  templateUrl: './request-order.component.html',
  styleUrls: ['./request-order.component.css']
})
export class RequestOrderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
