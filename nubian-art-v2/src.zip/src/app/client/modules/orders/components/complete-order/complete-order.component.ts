import { Component, OnInit } from '@angular/core';
import { AddressService } from 'src/app/core/services/address/address.service';
import { AuthService } from 'src/app/core/services/auth/auth.service';
import { CartService } from 'src/app/core/services/cart/cart.service';
import { ProductsService } from 'src/app/core/services/products/products.service';

@Component({
  selector: 'app-complete-order',
  templateUrl: './complete-order.component.html',
  styleUrls: ['./complete-order.component.css'],
})
export class CompleteOrderComponent implements OnInit {
  user: any;
  cartItemsArr: Array<any> = [];
  cartProducts: Array<any> = [];
  addresses: Array<any> = [];
  _addresses;
  address: string = '';
  town: string = '';
  city: string = '';
  totalPrice = 0;

  constructor(
    private authservice: AuthService,
    private cartservice: CartService,
    private productservice: ProductsService,
    private addressservice: AddressService
  ) {
    this.cartservice.getCartItems().subscribe((items) => {
      this.user = authservice.getUser;
      items.forEach((item) => {
        if (item.userId == this.authservice.getUser.uid) {
          this.cartItemsArr.push(item);
        }
      });
      items.forEach((item) => {
        this.productservice
          .getOneProduct(item.productId)
          .subscribe((product) => {
            this.cartProducts.push(product);
          });
      });
      this.addressservice
        .getAddressesByUid(this.authservice.getUser.uid)
        .then((adds) => {
          this._addresses = adds;
        });
      for (let i = 0; i < items.length; i++) {
        this.totalPrice += items[i].quantity * this.cartProducts[i].price;
      }
    });
    this.addressservice.getAddresses().then((adds) => {
      this.addresses = adds;
    });
  }

  ngOnInit(): void {}
  ngDoCheck() {
    console.log('coming items', this.cartProducts);
    console.log(this.cartItemsArr);
    console.log(this.user);
    console.log('Adresses', this._addresses);
  }
  addAddress() {
    this.addressservice.updateAddresses(this._addresses.id, {
      data: [
        this._addresses.data[0],
        {
          address: this.address,
          city: this.city,
          town: this.town,
          userID: this._addresses.data[0].userID,
        },
      ],
    });
  }
}
