import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-profile-edit',
  templateUrl: './profile-edit.component.html',
  styleUrls: ['./profile-edit.component.css'],
})
export class ProfileEditComponent implements OnInit {
  @Input() _user: any;
  isEdit: boolean = true;
  constructor() {
    console.log(this._user);
  }

  ngOnInit(): void {}
  updateProfile() {
    this.isEdit = false;
  }
}
