import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-wishlist',
  templateUrl: './order-wishlist.component.html',
  styleUrls: ['./order-wishlist.component.css'],
})
export class OrderWishlistComponent implements OnInit {
  @Input() wishListProducts;
  active = 1;
  constructor() {}

  ngOnInit(): void {}
}
