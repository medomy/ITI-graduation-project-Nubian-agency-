import { Component, DoCheck, OnChanges, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DocumentData } from 'rxfire/firestore/interfaces';
import { AuthService } from 'src/app/core/services/auth/auth.service';
import { ProductsService } from 'src/app/core/services/products/products.service';
import { UserService } from 'src/app/core/services/user/user.service';

import { WishlistService } from 'src/app/core/services/Wishlist/wishlist.service';

@Component({
  selector: 'app-profile-details',
  templateUrl: './profile-details.component.html',
  styleUrls: ['./profile-details.component.css'],
})
export class ProfileDetailsComponent implements OnInit, DoCheck, OnChanges {
  profileId: string;
  user: DocumentData;
  wishListProductsIds: Array<string> = [];
  wishListProducts: Array<any> = [];
  wishListId: string;

  constructor(
    private router: ActivatedRoute,
    private userServive: UserService,
    private wishlistservice: WishlistService,
    private authService: AuthService,
    private productssrvice: ProductsService
  ) {
    this.router.params.subscribe((param) => (this.profileId = param.id));
    this.userServive
      .getOneUser(this.profileId)
      .subscribe((data) => console.log(data));
    console.log(this.profileId);
    this.wishlistservice.getWishListByUid(this.profileId).then((wishlist) => {
      this.wishListId = wishlist.id;
      this.wishListProductsIds = wishlist.productsIds;
      this.wishListProductsIds.forEach((productid) => {
        this.productssrvice
          .getOneProduct(productid)
          .subscribe((product) => this.wishListProducts.push(product));
      });
    });
  }

  ngOnInit(): void {}

  get _user(): any {
    return this.authService.getUser;
  }
  ngDoCheck() {
    console.log(this.wishListProductsIds);
    console.log(this.wishListProducts);
  }

  ngOnChanges() {
    console.log(this.wishListProducts);
  }
  recieveProduct(product) {
    //this.addtowishlistservice.removeFromWishList(product.id);
    //this.addtowishlistservice.getWishList().subscribe((wishlistid)=> console.log(wishlistid));
    this.wishListProductsIds.forEach((productId, index) => {
      console.log(productId);
      if (product.id == productId) {
        this.wishListProductsIds.splice(index, 1);
      }
    });
    this.wishlistservice.updateWishlist(this.wishListId, {
      productsIds: this.wishListProductsIds,
    });
    console.log(this.wishListProductsIds);
    console.log(product);
  }
}
