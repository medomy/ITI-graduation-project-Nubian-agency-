import { Component, OnInit, ViewEncapsulation } from '@angular/core';
// import Swiper core and required modules
import SwiperCore, { Pagination, Navigation } from "swiper";

// install Swiper modules
SwiperCore.use([Pagination, Navigation]);
@Component({
  selector: 'app-our-artist',
  templateUrl: './our-artist.component.html',
  styleUrls: ['./our-artist.component.css'],
  encapsulation: ViewEncapsulation.None,

})
export class OurArtistComponent implements OnInit {

  artists = [

    {
      img: '../../../../../assets/images/users/artist/Salem.png',
      name: 'Salem',
      department: 'Interior designer'
    },

    {
      img: '../../../../../assets/images/users/artist/Salma.png',
      name: 'Salma',
      department: 'Ceramics Artist'
    },

    {
      img: '../../../../../assets/images/users/artist/Fatma.png',
      name: 'Fatma',
      department: 'Graffiti designer'
    }

  ]
  constructor() { }

  ngOnInit(): void {
  }



}
